# function-3d-visualizer

Visit the Live Website https://func-3dviz.web.app/

Having Trouble in Visualising Maths Equations ,try this free website to quickly visualize your equations.

Step 1: Go to https://func-3dviz.web.app/

Step 2: Enter Any Equation

<a href="https://ibb.co/prHhFwK"><img src="https://i.ibb.co/fG3DwFN/image-43.png" alt="image-43" border="0"></a>

Setp 3: Adjust Parameters if Needed:

<a href="https://imgbb.com/"><img src="https://i.ibb.co/yyvbpW9/image-44.png" alt="image-44" border="0"></a>

Step 4: Plot and Visualize:

<a href="https://ibb.co/5MHZscH"><img src="https://i.ibb.co/7Ymhrym/image-45.png" alt="image-45" border="0"></a>


## Usage:

1. Clone or Download The Repo :
 
     `git clone https://github.com/aniketdhole07/function-3d-visualizer.git`

 
2. Open The `index.html` file using Browser
 
## Tech Stack
1. FrontEnd : HTML,CSS
2. Backend : Javascript,Plotly

 
